import confetti_00 from './confetti_00.png';
import confetti_01 from './confetti_01.png';
import confetti_02 from './confetti_02.png';
import confetti_03 from './confetti_03.png';
import confetti_04 from './confetti_04.png';
import confetti_05 from './confetti_05.png';
import confetti_06 from './confetti_06.png';
import confetti_07 from './confetti_07.png';
import confetti_08 from './confetti_08.png';
export { confetti_00, confetti_01, confetti_02, confetti_03, confetti_04, confetti_05, confetti_06, confetti_07, confetti_08 }